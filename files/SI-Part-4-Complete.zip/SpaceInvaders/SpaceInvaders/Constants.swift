//
//  Constants.swift
//  Space Invaders
//
//  Created by The Architect on 4/2/23.
//  ©The Architect Labs - 2023
//  Website:  https://thearchitectlabs.github.io
//  YouTube:  https://www.youtube.com/@thearchitectlabs
//

import Foundation

enum k {
    
    enum scenes {
        static let open: String = "OpeningScene"
        static let game: String = "GameScene"
        static let summary: String = "SummaryScene"
    }
    
    enum layers {
        static let background: CGFloat = -20
        static let particles: CGFloat = -10
        static let labels: CGFloat = 0
        static let players: CGFloat = 10
    }
    
    enum fonts {
        static let normal: String = "HelveticaNeue-UltraLight"
        static let bold: String = "HelveticaNeue-Bold"
    }
}
