//
//  SummaryScene.swift
//  Space Invaders
//
//  Created by The Architect on 4/2/23.
//  ©The Architect Labs - 2023
//  Website:  https://thearchitectlabs.github.io
//  YouTube:  https://www.youtube.com/@thearchitectlabs
//

import SpriteKit

class SummaryScene: SKScene {
    
    override func didMove(to view: SKView) {
        // more code to come
    }
    
    override func update(_ currentTime: TimeInterval) {
        // more code to come
    }
}
