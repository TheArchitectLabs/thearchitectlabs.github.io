//
//  GameScene.swift
//  Space Invaders
//
//  Created by The Architect on 4/2/23.
//  ©The Architect Labs - 2023
//  Website:  https://thearchitectlabs.github.io
//  YouTube:  https://www.youtube.com/@thearchitectlabs
//

import SpriteKit
import CoreMotion

class GameScene: SKScene {
    
    // MARK: - PROPERTIES
    let player = SKSpriteNode(imageNamed: "PlayerCannon")
    let motionManager = CMMotionManager()
    
    // MARK: - METHODS
    override func didMove(to view: SKView) {
        createParticles()
        createPlayer()
        createBlocks()
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        
        // Control the movement of the player
        if let accelerometerData = motionManager.accelerometerData {
            player.position.x += CGFloat(accelerometerData.acceleration.x * 50)
            
            if player.position.x < frame.minX {
                player.position.x = frame.minX
            } else if player.position.x > frame.maxX {
                player.position.x = frame.maxX
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        // Make sure there is only one player shot on the screen at any time
        guard childNode(withName: "playerWeapon") == nil else { return }
        
        // Create a shot from player
        let playerShot = SKSpriteNode(color: .green, size: CGSize(width: 4, height: 12))
        playerShot.position = player.position
        playerShot.zPosition = k.layers.players
        playerShot.name = "playerWeapon"
        addChild(playerShot)
        
        let move = SKAction.move(to: CGPoint(x: playerShot.position.x, y: 1050), duration: 1.0)
        let seqence = SKAction.sequence([move, .removeFromParent()])
        let shotSound = SKAction.playSoundFileNamed("shoot.wav", waitForCompletion: true)
        playerShot.run(SKAction.group([seqence, shotSound]))
    }
    
    // MARK: - NODES
    func createParticles() {
        // Create our background SpaceDust and add to the scene
        guard let particles = SKEmitterNode(fileNamed: "SpaceDust") else { return }
        particles.position = CGPoint(x: frame.width / 2, y: frame.height / 2)
        particles.zPosition = k.layers.particles
        particles.advanceSimulationTime(10)
        addChild(particles)
    }
    
    func createBlocks() {
        // Create our defensive blocks and add to the scene
        for barrier in 0...3 {
            let startX = 132 + (barrier * 72) + (barrier * 72)
            
            for row in 1...3 {
                for col in 0...5 {
                    let block = SKSpriteNode(color: .green, size: CGSize(width: 12, height: 24))
                    block.position = CGPoint(x: startX + (Int(block.frame.width) * col), y: 250 + Int(block.frame.height) * row)
                    block.zPosition = k.layers.players
                    block.name = "block"
                    addChild(block)
                }
            }
        }
    }
    
    func createPlayer() {
        // Create our player and add to the scene
        player.size = CGSize(width: 72, height: 72)
        player.position = CGPoint(x: frame.width / 2, y: 80)
        player.zPosition = k.layers.players
        player.name = "player"
        addChild(player)
    }
}
