//
//  OpeningScene.swift
//  Space Invaders
//
//  Created by The Architect on 4/2/23.
//  ©The Architect Labs - 2023
//  Website:  https://thearchitectlabs.github.io
//  YouTube:  https://www.youtube.com/@thearchitectlabs
//

import SpriteKit

class OpeningScene: SKScene {
    
    // MARK: - PROPERTIES
    let startButton = SKLabelNode(fontNamed: k.fonts.bold)
    let hiScoreLabel = SKLabelNode(fontNamed: k.fonts.normal)
    let resetLabel = SKLabelNode(fontNamed: k.fonts.normal)
    var highScore: Int = 0 {
        didSet {
            hiScoreLabel.text = String(format: "%04d", highScore)
        }
    }
    
    // MARK: - METHODS
    override func didMove(to view: SKView) {
        createStartButton()
        createHiScoreLabel()
        createResetLabel()
        
        highScore = UserDefaults.standard.integer(forKey: k.userDefaults.hiScore)
    }
    
    override func update(_ currentTime: TimeInterval) {
        // more code to come
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        
        let location = touch.location(in: self)
        let tappedNodes = nodes(at: location)
        guard let tapped = tappedNodes.first else { return }
        
        if tapped.name == "start" {
            // Set the defaults for a new game
            UserDefaults.standard.set(0, forKey: k.userDefaults.score)
            UserDefaults.standard.set(2, forKey: k.userDefaults.lives)
            UserDefaults.standard.set(0, forKey: k.userDefaults.invadersDestroyed)
            UserDefaults.standard.set(0, forKey: k.userDefaults.shotsFired)
            UserDefaults.standard.set(1, forKey: k.userDefaults.level)
            UserDefaults.standard.set(0, forKey: k.userDefaults.mysteryPosition)
            
            // Open the game scene and begin play
            if let nextScene = GameScene(fileNamed: k.scenes.game){
                nextScene.scaleMode = self.scaleMode
                let transition = SKTransition.fade(withDuration: 1)
                view?.presentScene(nextScene, transition: transition)
            }
        } else if tapped.name == "reset" {
            highScore = 0
            UserDefaults.standard.set(0, forKey: k.userDefaults.hiScore)
        } else {
            return
        }
    }
    
    // MARK: - NODE METHODS
    
    func createStartButton() {
        startButton.position = CGPoint(x: frame.width / 2, y: 150)
        startButton.zPosition = k.layers.labels
        startButton.name = "start"
        startButton.text = "START"
        addChild(startButton)
    }
    
    func createHiScoreLabel() {
        hiScoreLabel.position = CGPoint(x: 384, y: 914)
        hiScoreLabel.zPosition = k.layers.labels
        hiScoreLabel.name = "hiscore"
        hiScoreLabel.text = "0000"
        addChild(hiScoreLabel)
    }
    
    func createResetLabel() {
        resetLabel.position = CGPoint(x: frame.width - 100, y: 100)
        resetLabel.zPosition = k.layers.labels
        resetLabel.fontSize = 18
        resetLabel.name = "reset"
        resetLabel.text = "RESET HI-SCORE"
        addChild(resetLabel)
    }
    
}
