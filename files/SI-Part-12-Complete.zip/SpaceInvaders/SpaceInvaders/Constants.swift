//
//  Constants.swift
//  Space Invaders
//
//  Created by The Architect on 4/2/23.
//  ©The Architect Labs - 2023
//  Website:  https://thearchitectlabs.github.io
//  YouTube:  https://www.youtube.com/@thearchitectlabs
//

import Foundation

enum k {
    
    enum scenes {
        static let open: String = "OpeningScene"
        static let game: String = "GameScene"
        static let summary: String = "SummaryScene"
    }
    
    enum layers {
        static let background: CGFloat = -20
        static let particles: CGFloat = -10
        static let labels: CGFloat = 0
        static let players: CGFloat = 10
    }
    
    enum fonts {
        static let normal: String = "HelveticaNeue-UltraLight"
        static let bold: String = "HelveticaNeue-Bold"
    }
    
    enum userDefaults {
        static let score: String = "score"
        static let hiScore: String = "hiscore"
        static let lives: String = "lives"
        static let shotsFired: String = "shotsfired"
        static let invadersDestroyed: String = "invadersdestroyed"
        static let level: String = "level"
        static let mysteryPosition: String = "mysteryPosition"
    }
    
    // Mystery Ship Bonus Point Array
    static let mysteryBonus: [Int] = [
        100, 50, 50, 100, 150,
        100, 100, 50, 300, 100,
        100, 100, 50, 150, 100
    ]
}

enum MoveDirection {
    case right
    case left
    case downThenRight
    case downThenLeft
    case none
}

enum CollisionType: UInt32 {
    case player = 1
    case playerWeapon = 2
    case invader = 4
    case invaderWeapon = 8
    case block = 16
    case mysteryInvader = 32
}
