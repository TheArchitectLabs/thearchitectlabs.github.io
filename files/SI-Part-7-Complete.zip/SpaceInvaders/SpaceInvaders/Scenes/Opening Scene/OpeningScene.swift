//
//  OpeningScene.swift
//  Space Invaders
//
//  Created by The Architect on 4/2/23.
//  ©The Architect Labs - 2023
//  Website:  https://thearchitectlabs.github.io
//  YouTube:  https://www.youtube.com/@thearchitectlabs
//

import SpriteKit

class OpeningScene: SKScene {
    
    // MARK: - PROPERTIES
    let startButton = SKLabelNode(fontNamed: k.fonts.bold)
    
    // MARK: - METHODS
    override func didMove(to view: SKView) {
        createStartButton()
    }
    
    override func update(_ currentTime: TimeInterval) {
        // more code to come
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        
        let location = touch.location(in: self)
        let tappedNodes = nodes(at: location)
        guard let tapped = tappedNodes.first else { return }
        
        if tapped.name == "start" {
            // Open the game scene and begin play
            if let nextScene = GameScene(fileNamed: k.scenes.game){
                nextScene.scaleMode = self.scaleMode
                let transition = SKTransition.fade(withDuration: 1)
                view?.presentScene(nextScene, transition: transition)
            }
        } else {
            return
        }
    }
    
    // MARK: - NODE METHODS
    
    func createStartButton() {
        startButton.position = CGPoint(x: frame.width / 2, y: 150)
        startButton.zPosition = k.layers.labels
        startButton.name = "start"
        startButton.text = "START"
        addChild(startButton)
    }
    
}
