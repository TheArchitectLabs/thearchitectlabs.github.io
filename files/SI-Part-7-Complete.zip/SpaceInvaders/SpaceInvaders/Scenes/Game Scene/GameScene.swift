//
//  GameScene.swift
//  Space Invaders
//
//  Created by The Architect on 4/2/23.
//  ©The Architect Labs - 2023
//  Website:  https://thearchitectlabs.github.io
//  YouTube:  https://www.youtube.com/@thearchitectlabs
//

import SpriteKit
import CoreMotion

class GameScene: SKScene, SKPhysicsContactDelegate {
    
    // MARK: - PROPERTIES
    let player = SKSpriteNode(imageNamed: "PlayerCannon")
    let motionManager = CMMotionManager()
    
    // Invader Properties
    let invaders: [String] = ["InvaderA", "InvaderB", "InvaderC"]
    var moveDirection: MoveDirection = .right
    var timeOfLastMove: CFTimeInterval = 2.0
    var timePerMove: CFTimeInterval = 0.5
    var moveSound: String = "fastinvader3"
    var invaderCompressed: Bool = false
    var totalInvaders: Int = 55
    var timeOfLastShot: CFTimeInterval = 2.0
    
    // Other Properties
    var isGameStarted: Bool = false
    
    // MARK: - METHODS
    override func didMove(to view: SKView) {
        // Set up physics
        physicsWorld.contactDelegate = self
        physicsWorld.gravity = .zero
        
        // Start the Core Motion Updates
        motionManager.startAccelerometerUpdates()
        
        // Add the nodes to the scene
        createParticles()
        createBlocks()
        createPlayer()
        createInvaders()
    }
    
    override func update(_ currentTime: TimeInterval) {
        if isGameStarted {
            // Control the movement of the invaders
            if currentTime - timeOfLastMove >= timePerMove {
                let move = SKAction.run { self.moveInvaders() }
                let moveSound = SKAction.playSoundFileNamed(moveSound, waitForCompletion: true)
                let sequence = SKAction.sequence([move, moveSound])
                self.run(sequence)
                self.timeOfLastMove = currentTime
            }
            
            // Have a random invader shoot once per second
            if totalInvaders > 0 {
                if currentTime - timeOfLastShot > 1.0 {
                    self.timeOfLastShot = currentTime
                    var remainingInvaders = [SKNode]()
                    enumerateChildNodes(withName: "Invader*") { node, _ in
                        remainingInvaders.append(node)
                    }
                    let remaininInvaderIndex = Int(arc4random_uniform(UInt32(remainingInvaders.count)))
                    let shooter = remainingInvaders[remaininInvaderIndex]
                    let invaderShot = SKSpriteNode(color: .red, size: CGSize(width: 4, height: 12))
                    invaderShot.position = shooter.position
                    invaderShot.zPosition = k.layers.players
                    invaderShot.name = "invaderWeapon"
                    addChild(invaderShot)
                    
                    invaderShot.physicsBody = SKPhysicsBody(rectangleOf: invaderShot.size)
                    invaderShot.physicsBody?.categoryBitMask = CollisionType.invaderWeapon.rawValue
                    invaderShot.physicsBody?.collisionBitMask = CollisionType.player.rawValue | CollisionType.playerWeapon.rawValue | CollisionType.block.rawValue
                    invaderShot.physicsBody?.contactTestBitMask = CollisionType.player.rawValue | CollisionType.playerWeapon.rawValue | CollisionType.block.rawValue
                    invaderShot.physicsBody?.isDynamic = false
                    
                    let move = SKAction.move(to: CGPoint(x: shooter.position.x, y: 25), duration: 1.0)
                    let sequence = SKAction.sequence([move, .removeFromParent()])
                    let shotSound = SKAction.playSoundFileNamed("shoot.wav", waitForCompletion: true)
                    invaderShot.run(SKAction.group([sequence, shotSound]))
                }
            }
        } else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                self.isGameStarted = true
            }
        }
        
        // Control the movement of the player
        if let accelerometerData = motionManager.accelerometerData {
            player.position.x += CGFloat(accelerometerData.acceleration.x * 50)
            
            if player.position.x < frame.minX {
                player.position.x = frame.minX
            } else if player.position.x > frame.maxX {
                player.position.x = frame.maxX
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        // Ensure there is only one player weapon on the scene at any time. If none, create a new one from the current player location.
        guard childNode(withName: "playerWeapon") == nil else { return }
        let playerShot = SKSpriteNode(color: .green, size: CGSize(width: 4, height: 12))
        playerShot.position = player.position
        playerShot.zPosition = k.layers.players
        playerShot.name = "playerWeapon"
        addChild(playerShot)
        
        playerShot.physicsBody = SKPhysicsBody(rectangleOf: playerShot.size)
        playerShot.physicsBody?.categoryBitMask = CollisionType.playerWeapon.rawValue
        playerShot.physicsBody?.collisionBitMask = CollisionType.invader.rawValue | CollisionType.invaderWeapon.rawValue | CollisionType.block.rawValue
        playerShot.physicsBody?.contactTestBitMask = CollisionType.invader.rawValue | CollisionType.invaderWeapon.rawValue | CollisionType.block.rawValue
        playerShot.physicsBody?.isDynamic = false
        
        let move = SKAction.move(to: CGPoint(x: playerShot.position.x, y: 1050), duration: 1.0)
        let sequence = SKAction.sequence([move, .removeFromParent()])
        let shotSound = SKAction.playSoundFileNamed("ShipBullet.wav", waitForCompletion: true)
        playerShot.run(SKAction.group([sequence, shotSound]))
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        // more code to come
    }
    
    // MARK: - NODE METHODS
    func createParticles() {
        guard let particles = SKEmitterNode(fileNamed: "SpaceDust") else { return }
        particles.position = CGPoint(x: frame.width / 2, y: frame.height / 2)
        particles.zPosition = k.layers.particles
        particles.advanceSimulationTime(10)
        addChild(particles)
    }
    
    func createBlocks() {
        for barrier in 0...3 {
            let startX = 132 + (barrier * 72) + (barrier * 72)
            
            for row in 1...3 {
                for col in 0...5 {
                    let block = SKSpriteNode(color: .green, size: CGSize(width: 12, height: 24))
                    block.position = CGPoint(x: startX + (Int(block.frame.width) * col), y: 250 + Int(block.frame.height) * row)
                    block.zPosition = k.layers.players
                    block.name = "block"
                    addChild(block)
                    
                    block.physicsBody = SKPhysicsBody(rectangleOf: block.size)
                    block.physicsBody?.categoryBitMask = CollisionType.block.rawValue
                    block.physicsBody?.collisionBitMask = CollisionType.invaderWeapon.rawValue | CollisionType.playerWeapon.rawValue | CollisionType.invader.rawValue
                    block.physicsBody?.contactTestBitMask = CollisionType.invaderWeapon.rawValue | CollisionType.playerWeapon.rawValue | CollisionType.invader.rawValue
                    block.physicsBody?.isDynamic = true
                }
            }
        }
    }
    
    func createPlayer() {
        player.size = CGSize(width: 72, height: 72)
        player.position = CGPoint(x: frame.width / 2, y: 78)
        player.zPosition = k.layers.players
        player.name = "player"
        addChild(player)
        
        player.physicsBody = SKPhysicsBody(texture: player.texture!, size: player.size)
        player.physicsBody?.categoryBitMask = CollisionType.player.rawValue
        player.physicsBody?.collisionBitMask = CollisionType.invader.rawValue | CollisionType.invaderWeapon.rawValue
        player.physicsBody?.contactTestBitMask = CollisionType.invader.rawValue | CollisionType.invaderWeapon.rawValue
        player.physicsBody?.isDynamic = true
    }
    
    func createInvaders() {
        var invaderSprite: String?
        
        for row in 1...5 {
            if row == 1 {
                invaderSprite = invaders[0]
            } else if row == 2 || row == 3 {
                invaderSprite = invaders[1]
            } else {
                invaderSprite = invaders[2]
            }
            
            for col in 1...11 {
                let invader = SKSpriteNode(imageNamed: "\(invaderSprite!)_01")
                invader.size = CGSize(width: 42, height: 42)
                invader.position = CGPoint(x: Int(invader.size.width * 1.25) * col, y: 810 - (row * Int(invader.size.height)))
                invader.zPosition = k.layers.players
                invader.name = invaderSprite
                addChild(invader)
                
                invader.physicsBody = SKPhysicsBody(texture: invader.texture!, size: invader.size)
                invader.physicsBody?.categoryBitMask = CollisionType.invader.rawValue
                invader.physicsBody?.collisionBitMask = CollisionType.player.rawValue | CollisionType.playerWeapon.rawValue
                invader.physicsBody?.contactTestBitMask = CollisionType.player.rawValue | CollisionType.playerWeapon.rawValue | CollisionType.block.rawValue
                invader.physicsBody?.isDynamic = true
            }
        }
    }
    
    func moveInvaders() {
        determineMoveDirection()
        invaderCompressed.toggle()
        
        enumerateChildNodes(withName: "Invader*") { [self] node, stop in
            switch self.moveDirection {
            case .right:
                node.position = CGPoint(x: node.position.x + 10, y: node.position.y)
            case .left:
                node.position = CGPoint(x: node.position.x - 10, y: node.position.y)
            case .downThenRight, .downThenLeft:
                node.position = CGPoint(x: node.position.x, y: node.position.y - 15)
            case .none:
                break
            }
            let compress = SKAction.setTexture(SKTexture(imageNamed: self.invaderCompressed ? "\(node.name!)_02" : "\(node.name!)_01"))
            node.run(compress)
        }
    }
    
    func determineMoveDirection() {
        var proposedDirection: MoveDirection = moveDirection
        
        enumerateChildNodes(withName: "Invader*") { node, stop in
            switch self.moveDirection {
            case .right:
                if node.frame.maxX >= self.frame.width - 50 {
                    proposedDirection = .downThenLeft
                }
            case .left:
                if node.frame.minX <= 50 {
                    proposedDirection = .downThenRight
                }
            case .downThenRight:
                proposedDirection = .right
            case .downThenLeft:
                proposedDirection = .left
            default:
                break
            }
        }
        
        if proposedDirection != moveDirection {
            moveDirection = proposedDirection
        }
    }
}
